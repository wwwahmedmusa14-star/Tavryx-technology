/* TAVRYX TECHNOLOGIES - edit your WhatsApp number here (country code, no + or spaces) */
var WHATSAPP_NUMBER = "234XXXXXXXXXX";

var T = {
en:{nav_home:"Home",nav_services:"Services",nav_vision:"Vision",nav_request:"Request",nav_client:"Client Area",nav_contact:"Contact",nav_admin:"Admin",
tagline:"Building Technology for Tomorrow.",hero_title:"Your Vision, Our Technology.",
hero_text:"We design and build websites, apps and AI tools for businesses and individuals who want to grow with technology.",
cta_request:"Request a Service",cta_services:"See Services",services_title:"What we do",
s1_t:"Web Development",s1_d:"Fast, mobile-friendly websites for your business.",s2_t:"AI Solutions",s2_d:"Practical AI tools that save time and reduce cost.",
s3_t:"Mobile Apps",s3_d:"Apps that work well on the phones your customers use.",s4_t:"Digital Solutions",s4_d:"Systems that move your daily work online.",
s5_t:"Branding & Design",s5_d:"Logos, posters and a look people remember.",s6_t:"Tech Support",s6_d:"Help when something breaks or you need advice.",
vision_title:"Our vision",vision_text:"To make good technology reachable for every business and person in Nigeria and across Africa, built with care and honest work.",
v1:"Honest pricing and clear timelines",v2:"Work that runs well on low-end phones and slow networks",v3:"English and Hausa support",
req_title:"Request a service",f_name:"Full name",f_phone:"Phone / WhatsApp",f_service:"Service",f_details:"Tell us what you need",f_save:"Save request",f_wa:"Send on WhatsApp",
saved:"Request saved on this device. Send it on WhatsApp so we can see it.",
client_title:"Client area",client_note:"Enter your name and phone to see requests saved on this device.",client_open:"Open my area",logout:"Log out",
hello:"Hello, ",no_reqs:"No requests yet.",
admin_title:"Admin dashboard",pass:"Passcode",admin_open:"Open dashboard",admin_reqs:"All requests on this device",admin_clear:"Delete all requests",
admin_new:"First time: choose a passcode (4+ characters) for this device.",admin_have:"Enter your admin passcode.",admin_bad:"Wrong passcode.",confirm_clear:"Delete all requests?",
contact_title:"Contact us",contact_text:"Message us and we will reply as soon as we can.",wa_chat:"Chat on WhatsApp",f_msg:"Message",send_wa:"Send via WhatsApp",rights:"All rights reserved.",
st_new:"New",st_progress:"In progress",st_done:"Done"},
ha:{nav_home:"Gida",nav_services:"Ayyuka",nav_vision:"Hangen Nesa",nav_request:"Nema",nav_client:"Yankin Abokin Ciniki",nav_contact:"Tuntuɓa",nav_admin:"Admin",
tagline:"Gina Fasaha Don Gobe.",hero_title:"Burinku, Fasaharmu.",
hero_text:"Muna tsarawa da gina shafukan yanar gizo, manhajoji da kayan AI ga kasuwanci da mutane masu son ci gaba da fasaha.",
cta_request:"Nemi Aiki",cta_services:"Duba Ayyuka",services_title:"Abin da muke yi",
s1_t:"Gina Shafin Yanar Gizo",s1_d:"Shafuka masu sauri kuma masu aiki a waya ga kasuwancinku.",s2_t:"Mafita ta AI",s2_d:"Kayan AI masu rage lokaci da kuɗi.",
s3_t:"Manhajojin Waya",s3_d:"Manhajoji masu aiki da kyau a wayoyin abokan cinikinku.",s4_t:"Mafitar Dijital",s4_d:"Tsare-tsaren da ke kai aikinku na yau da kullum kan yanar gizo.",
s5_t:"Alama & Zane",s5_d:"Tambari, fosta da kamanni da za a tuna.",s6_t:"Tallafin Fasaha",s6_d:"Taimako idan wani abu ya lalace ko kuna buƙatar shawara.",
vision_title:"Hangenmu",vision_text:"Mu sa fasaha mai kyau ta isa ga kowane kasuwanci da mutum a Najeriya da Afirka, cikin kulawa da gaskiya.",
v1:"Gaskiya a farashi da lokaci",v2:"Aiki mai gudana a wayoyi marasa ƙarfi da hanyar sadarwa mai jinkiri",v3:"Tallafi da Turanci da Hausa",
req_title:"Nemi wani aiki",f_name:"Cikakken suna",f_phone:"Waya / WhatsApp",f_service:"Aiki",f_details:"Gaya mana abin da kuke buƙata",f_save:"Ajiye buƙata",f_wa:"Aika ta WhatsApp",
saved:"An ajiye buƙatar a wannan na'ura. Aika ta WhatsApp domin mu gani.",
client_title:"Yankin abokin ciniki",client_note:"Shigar da suna da waya don ganin buƙatun da aka ajiye a wannan na'ura.",client_open:"Buɗe yankina",logout:"Fita",
hello:"Sannu, ",no_reqs:"Babu buƙata tukuna.",
admin_title:"Dashboard na Admin",pass:"Lambar sirri",admin_open:"Buɗe dashboard",admin_reqs:"Duk buƙatun da ke wannan na'ura",admin_clear:"Share duk buƙatun",
admin_new:"Farko: zaɓi lambar sirri (haruffa 4 ko fiye) don wannan na'ura.",admin_have:"Shigar da lambar sirrin admin.",admin_bad:"Lambar sirri ba daidai ba.",confirm_clear:"Share duk buƙatun?",
contact_title:"Tuntuɓe mu",contact_text:"Aiko mana saƙo, za mu amsa da wuri.",wa_chat:"Yi magana a WhatsApp",f_msg:"Saƙo",send_wa:"Aika ta WhatsApp",rights:"An kiyaye duk haƙƙoƙi.",
st_new:"Sabo",st_progress:"Ana aiki",st_done:"An gama"}
};
var lang = "en";
function $(s){return document.querySelector(s);}
function tr(k){return (T[lang]&&T[lang][k])||T.en[k]||k;}
function load(k,d){try{var v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch(e){return d;}}
function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function esc(s){var d=document.createElement("div");d.textContent=s;return d.innerHTML;}
function wa(text){return "https://wa.me/"+WHATSAPP_NUMBER+"?text="+encodeURIComponent(text);}

function applyLang(){
  document.documentElement.lang=lang;
  document.querySelectorAll("[data-i18n]").forEach(function(el){el.textContent=tr(el.getAttribute("data-i18n"));});
  $("#langBtn").textContent = lang==="en" ? "HA" : "EN";
  $("#adminNote").textContent = tr(load("tvx_admin",null) ? "admin_have" : "admin_new");
  save("tvx_lang",lang);
  renderClient(); renderAdmin();
}
$("#langBtn").onclick=function(){lang=lang==="en"?"ha":"en";applyLang();};
$("#menuBtn").onclick=function(){$("#nav").classList.toggle("open");};
document.querySelectorAll("#nav a").forEach(function(a){a.onclick=function(){$("#nav").classList.remove("open");};});
$("#yr").textContent=new Date().getFullYear();
$("#waLink").href=wa("Hello TAVRYX TECHNOLOGIES");

/* Requests */
function getReqs(){return load("tvx_reqs",[]);}
function reqText(r){return "TAVRYX request\nName: "+r.name+"\nPhone: "+r.phone+"\nService: "+r.service+"\nDetails: "+r.details;}
var lastReq=null;
$("#reqForm").onsubmit=function(e){
  e.preventDefault();
  var f=e.target;
  var r={id:Date.now(),name:f.name.value.trim(),phone:f.phone.value.trim(),service:f.service.value,details:f.details.value.trim(),status:"new",date:new Date().toLocaleDateString()};
  var all=getReqs();all.unshift(r);save("tvx_reqs",all);lastReq=r;
  $("#reqMsg").textContent=tr("saved");
  f.details.value="";
  renderClient();renderAdmin();
};
$("#reqWa").onclick=function(){
  var f=$("#reqForm");
  var r=lastReq||{name:f.name.value,phone:f.phone.value,service:f.service.value,details:f.details.value};
  window.open(wa(reqText(r)),"_blank");
};

/* Client area (data stays on this device) */
var client=load("tvx_client",null);
$("#clientForm").onsubmit=function(e){
  e.preventDefault();
  client={name:e.target.name.value.trim(),phone:e.target.phone.value.trim()};
  save("tvx_client",client);renderClient();
};
$("#clientLogout").onclick=function(){client=null;try{localStorage.removeItem("tvx_client");}catch(e){}renderClient();};
function statusLabel(s){return tr(s==="done"?"st_done":s==="progress"?"st_progress":"st_new");}
function renderClient(){
  $("#clientOut").hidden=!!client;$("#clientIn").hidden=!client;
  if(!client)return;
  $("#clientHi").textContent=tr("hello")+client.name;
  var mine=getReqs().filter(function(r){return r.phone===client.phone;});
  $("#clientList").innerHTML=mine.length?mine.map(function(r){
    return '<div class="item"><b>'+esc(r.service)+'</b> - '+esc(statusLabel(r.status))+'<small>'+esc(r.date)+'</small>'+esc(r.details)+'</div>';
  }).join(""):'<p class="note">'+tr("no_reqs")+'</p>';
}

/* Admin dashboard. Passcode is only a local lock on this device, not real server security. */
function hash(s){
  if(window.crypto&&crypto.subtle&&window.TextEncoder){
    return crypto.subtle.digest("SHA-256",new TextEncoder().encode("tvx:"+s)).then(function(b){
      return Array.prototype.map.call(new Uint8Array(b),function(x){return ("0"+x.toString(16)).slice(-2);}).join("");
    });
  }
  return Promise.resolve("b:"+btoa(unescape(encodeURIComponent("tvx:"+s))));
}
var adminOn=false;
$("#adminForm").onsubmit=function(e){
  e.preventDefault();
  var p=e.target.pass.value;
  hash(p).then(function(h){
    var stored=load("tvx_admin",null);
    if(!stored){save("tvx_admin",h);adminOn=true;}
    else if(stored===h){adminOn=true;}
    else{alert(tr("admin_bad"));return;}
    e.target.pass.value="";renderAdmin();applyLang();
  });
};
$("#adminLogout").onclick=function(){adminOn=false;renderAdmin();};
$("#adminClear").onclick=function(){if(confirm(tr("confirm_clear"))){save("tvx_reqs",[]);renderAdmin();renderClient();}};
function renderAdmin(){
  $("#adminOut").hidden=adminOn;$("#adminIn").hidden=!adminOn;
  if(!adminOn)return;
  var all=getReqs();
  $("#adminList").innerHTML=all.length?all.map(function(r){
    var sel=["new","progress","done"].map(function(s){return '<option value="'+s+'"'+(r.status===s?" selected":"")+'>'+esc(statusLabel(s))+'</option>';}).join("");
    return '<div class="item"><b>'+esc(r.service)+'</b> - '+esc(r.name)+' ('+esc(r.phone)+')<small>'+esc(r.date)+'</small>'+esc(r.details)+'<br><select data-id="'+r.id+'">'+sel+'</select></div>';
  }).join(""):'<p class="note">'+tr("no_reqs")+'</p>';
  document.querySelectorAll("#adminList select").forEach(function(s){
    s.onchange=function(){var a=getReqs();a.forEach(function(r){if(String(r.id)===s.dataset.id)r.status=s.value;});save("tvx_reqs",a);renderClient();};
  });
}

/* Contact */
$("#contactForm").onsubmit=function(e){
  e.preventDefault();
  window.open(wa("From "+e.target.name.value+": "+e.target.msg.value),"_blank");
};

lang=load("tvx_lang","en");
applyLang();
